import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

public class TaskView {
    public StackPane getView() {
        return new StackPane(new Label("[A] 預算任務功能尚未實作"));
    }
}
