import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

public class CalendarView {
    public StackPane getView() {
        return new StackPane(new Label("[E] 記帳日曆功能尚未實作"));
    }
}
